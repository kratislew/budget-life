package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.User;
import com.budget.dao.UserDao;
import com.budget.inmemory.UserInMemory;
import com.budget.services.UserService;

/**
 * Servlet implementation class AccountServlet
 */
//@WebServlet(description = "Budget Life", urlPatterns = { "/account" })
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    UserService users;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        this.users = new UserInMemory();
        this.users = new UserDao();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = "";
        String password = "";
        String id = request.getParameter("id");
        if (id == null || "".equals(id)) {
            // Initialize id and continue with the rendering.
            id = "";
        } else {
            // Read the record from memory.
            User user = this.users.readUser(id);
            if (user == null) {
                // User not found, initialize id and continue with the rendering.
                id = "";
            } else {
                // User found, initialize variables.
                username = user.getUserName();
                password = user.getPassword();
                		
            }
        }

        request.setAttribute("form_username", username);
        request.setAttribute("form_password", password);
        RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
        dispatcher.forward(request, response);

    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }    

}
