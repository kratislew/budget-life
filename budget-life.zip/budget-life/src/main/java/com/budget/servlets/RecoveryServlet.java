package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.User;
import com.budget.dao.UserDao;
import com.budget.inmemory.UserInMemory;
import com.budget.services.UserService;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Servlet implementation class RecoveryServlet
 */
@WebServlet("/RecoveryServlet")
public class RecoveryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	UserService users;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecoveryServlet() {
        super();
        this.users = new UserInMemory();
        this.users = new UserDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
        User user = this.users.findUser(email);
       	String password = user.getPassword();
		
		
        
        //TO DO 
        /*
        String from = "budgetlife@gmail.com";
        String host = "smtp.gmail.com";
        Properties properties = System.getProperties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");

        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {

            protected PasswordAuthentication getPA() {
                return new PasswordAuthentication("budgetlife@gmail.com", "*******");
            }

        });
        session.setDebug(true);
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
            message.setSubject("Password Recovery");
            message.setText("Your Password is: " + password);

            System.out.println("sending...");
            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
        */
        
       	String passReset =
       			"<!DOCTYPE html>\n" + "	<html lang=\"en\">\n" + "	    <head>\n"
                   + "	        <title>Password Sent</title>\n </head>"
                   + "<body> Your password has been sent to you, it is " + password
            		+ "<a href='login'>OK</a> \n"
                   + "</body>\n ";
       	PrintWriter writer = response.getWriter();
       	writer.write(passReset);
       	 
	}

}
