package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.User;
import com.budget.dao.UserDao;
import com.budget.inmemory.UserInMemory;
import com.budget.services.UserService;

/**
 * Servlet implementation class VerificationServlet
 */
@WebServlet("/VerificationServlet")
public class VerificationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserService users;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VerificationServlet() {
        super();
        this.users = new UserInMemory();
        this.users = new UserDao();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
        User user = this.users.findUser(email);
        //user.setAuthenticated(true);
    	String auth =
       			"<!DOCTYPE html>\n" + "	<html lang=\"en\">\n" + "	    <head>\n"
                   + "	        <title>Thank you!</title>\n </head>"
                   + "<body> Your email has been verified!"
            		+ "<a href='index.html'>Return Home</a> \n"
                   + "</body>\n ";
       	PrintWriter writer = response.getWriter();
       	writer.write(auth);
       	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
