package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.User;
import com.budget.beans.UserProxy;
import com.budget.dao.UserDao;
import com.budget.inmemory.UserInMemory;
import com.budget.services.UserService;

/**
 * Servlet implementation class SignUpServlet
 */
//@WebServlet(description = "Budget Life", urlPatterns = { "/signup" })
public class SignUpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    UserService users;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpServlet() {
        super();
        this.users = new UserInMemory();
        this.users = new UserDao();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = "";
        String password = "";
        String email = "";
        String firstName = "";
        String lastName = "";
        double incomeAmount = 0; 
        String incomeType = "";
        String id = request.getParameter("id");
        if (id == null || "".equals(id)) {
            // Initialize id and continue with the rendering.
            id = "";
        } else {
            // Read the record from memory.
            User user = this.users.readUser(id);
            if (user == null) {
                // User not found, initialize id and continue with the rendering.
                id = "";
            } else {
                // User found, initialize variables.
                username = user.getUserName();
                password = user.getPassword();
                email = user.getEmail();
                firstName = user.getFirstName();
                lastName = user.getLastName();
                incomeAmount = user.getIncomeAmount();
                incomeType = user.getIncomeType();
                		
            }
        }

        request.setAttribute("form_id", id);
        request.setAttribute("form_username", username);
        request.setAttribute("form_password", password);
        request.setAttribute("form_email", email);
        request.setAttribute("form_fn", firstName);
        request.setAttribute("form_ln", lastName);
        request.setAttribute("form_incAmount", incomeAmount);
        request.setAttribute("form_incType", incomeType);
        RequestDispatcher dispatcher = request.getRequestDispatcher("signup.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    	
    	User user = null;
        String id = request.getParameter("id");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String incomeAmount = request.getParameter("incomeAmount");
        String incomeType = request.getParameter("incomeType");

        if (id == null || "".equals(id)) {
            // Create the user.
            user = new User(username, password, email, firstName, lastName, Double.valueOf(incomeAmount), incomeType);
        } else {
            // Read the log.
            user = this.users.readUser(id);
            user.setUserName(username);
            user.setPassword(password);
            user.setEmail(email);
            user.setFirstName(firstName);
            user.setLastName(lastName);
            user.setIncomeAmount(Double.valueOf(incomeAmount));
            user.setIncomeType(incomeType);
        }
        // Update the user.
        this.users.createOrUpdateUser(user);

        // Process GET for rendering the page with updates.
        doGet(request, response);
        
        
    }

}
