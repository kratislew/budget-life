package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.User;
import com.budget.dao.UserDao;
import com.budget.inmemory.UserInMemory;
import com.budget.services.UserService;

/**
 * Servlet implementation class AccountServlet
 */
//@WebServlet(description = "Budget Life", urlPatterns = { "/account" })
public class AccountServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    UserService users;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountServlet() {
        super();
        this.users = new UserInMemory();
        this.users = new UserDao();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

                		
            }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    	 String id = request.getParameter("id");
         String username = request.getParameter("username");
         String password = request.getParameter("password");
         if(this.users.verifyUser(username, password) == false) {
        	 String wrongLogin =
        			"<!DOCTYPE html>\n" + "	<html lang=\"en\">\n" + "	    <head>\n"
                    + "	        <title>Incorrect Login</title>\n"
                    + "<body> Wrong username or password, please try again."
             		+ "<a href='login'>OK</a> \n"
                    + "<a href='forgotPass'>Forgot Password</a> \n ";
        	 PrintWriter writer = response.getWriter();
        	 writer.write(wrongLogin);
        	 
         }
         else {
        	 User user = users.findUser(username, password);
        	 user.updateLoginStatus(true);
        	 // Render response.
        	 request.setAttribute("form_user", user);
             RequestDispatcher dispatcher = request.getRequestDispatcher("account.jsp");
             dispatcher.forward(request, response);

         }
         
    }


}
