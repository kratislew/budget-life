package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.User;
import com.budget.dao.UserDao;
import com.budget.inmemory.UserInMemory;
import com.budget.services.UserService;

/**
 * Servlet implementation class AccountServlet
 */
//@WebServlet(description = "Budget Life", urlPatterns = { "/logout" })
public class LogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    UserService users;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoutServlet() {
        super();
        this.users = new UserInMemory();
        this.users = new UserDao();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    	Map<UUID, User> userMap = this.users.readUsers();
        for (Map.Entry<UUID, User> loggedIn : userMap.entrySet()) {
        	if(loggedIn.getValue().isLogIn()) {
        		loggedIn.getValue().updateLoginStatus(false);
        		System.out.println(loggedIn.getValue().isLogIn());
        	}
        }
               
        // Render response.
        RequestDispatcher dispatcher = request.getRequestDispatcher("income.jsp");
        dispatcher.forward(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

}
