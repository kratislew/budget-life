package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.Income;
import com.budget.beans.Value;
import com.budget.dao.IncomeDao;
import com.budget.inmemory.ApplicationInMemory;
import com.budget.services.ApplicationService;

/**
 * Servlet implementation class ValueServlet
 */
//@WebServlet(description = "Budget Life", urlPatterns = { "/income" })
public class IncomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    ApplicationService values;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public IncomeServlet() {
        super();
        this.values = new ApplicationInMemory();
        this.values = new IncomeDao();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            delete(request);
        }

        String title = "";
        double amount = 0.0;
        Date date;
        String description = "";
        String id = request.getParameter("id");
        if (id == null || "".equals(id)) {
            // Initialize id and continue with the rendering.
            id = "";
        } else {
            // Read the record from memory.
            Value value = this.values.readValue(id);
            if (value == null) {
                // Value not found, initialize id and continue with the rendering.
                id = "";
            } else {
                // Value found, initialize title, amount, and description.
                title = value.getTitle();
                amount = value.getAmount();
                description = value.getDesc();
                date = value.getDate();            }
        }

        // Render response.
        Map<UUID, Value> values = this.values.readValues();
        
        request.setAttribute("form_id", id);
        request.setAttribute("form_title", title);
        request.setAttribute("form_amount", String.valueOf(amount));
        request.setAttribute("form_desc", description);
        request.setAttribute("values_map", values);
        RequestDispatcher dispatcher = request.getRequestDispatcher("income.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Value value = null;
        String id = request.getParameter("id");
        String amount = request.getParameter("amount");
        String title = request.getParameter("title");
        String date = request.getParameter("date");
        String description = request.getParameter("description");
        if (id == null || "".equals(id)) {
            // Create the value.
            value = new Income((Double.valueOf(amount)), title, description);
        } else {
            // Read the log.
            value = this.values.readValue(id);
            value.setTitle(title);
            value.setAmount(Double.valueOf(amount));
            value.setDesc(description);
        }
        // Update the log.
        this.values.createOrUpdateValue(value);

        // Process GET for rendering the page with updates.
        doGet(request, response);
    }

    private void delete(HttpServletRequest request) throws ServletException, IOException {
        String id = request.getParameter("id");
        if (id != null && !id.equals("null")) {
            // Remove the log.
            this.values.deleteValue(id);
        }
    }

}
