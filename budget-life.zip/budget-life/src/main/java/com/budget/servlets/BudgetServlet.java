package com.budget.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.budget.beans.Value;
import com.budget.dao.ExpenseDao;
import com.budget.dao.IncomeDao;
import com.budget.inmemory.ApplicationInMemory;
import com.budget.services.ApplicationService;
import com.budget.beans.User;
import com.budget.dao.UserDao;
import com.budget.inmemory.UserInMemory;
import com.budget.services.UserService;


/**
 * Servlet implementation class budgetServlet
 */
@WebServlet("/budgetServlet")
public class BudgetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    ApplicationService expenses;
    ApplicationService income;
	UserService user;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BudgetServlet() {
        super();
        this.expenses = new ApplicationInMemory();
        this.expenses = new ExpenseDao();
        this.income = new ApplicationInMemory();
        this.income = new IncomeDao();
        this.user = new UserInMemory();
        this.user = new UserDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		double totIncome = 0;
		double totExpense = 0;
		boolean userLog = false;
		
		Map<UUID, User> users = this.user.readUsers();
        for (Map.Entry<UUID, User> loggedIn : users.entrySet()) {
        	if(loggedIn.getValue().isLogIn()) {
        		userLog = true;
        		if(loggedIn.getValue().getIncomeType().equalsIgnoreCase("hourly"))
        			totIncome = (loggedIn.getValue().getIncomeAmount()) * 160.0;
        		else if(loggedIn.getValue().getIncomeType().equalsIgnoreCase("monthly"))
        			totIncome = loggedIn.getValue().getIncomeAmount();
        		else if(loggedIn.getValue().getIncomeType().equalsIgnoreCase("yearly"))
        			totIncome = (loggedIn.getValue().getIncomeAmount()) / 12.0;
        		
        	}
        }
        
        Map<UUID, Value> expValues = this.expenses.readValues();
        for (Map.Entry<UUID, Value> expItem : expValues.entrySet()) {
        	totExpense += expItem.getValue().getAmount();
        }
        
        Map<UUID, Value> incValues = this.income.readValues();
        for (Map.Entry<UUID, Value> incItem : incValues.entrySet()) {
        	totIncome += incItem.getValue().getAmount();
        }
        
        double total = totIncome - totExpense;
        // Render response.
        
        request.setAttribute("form_total", total);
        request.setAttribute("form_incTot", totIncome);
        request.setAttribute("form_expTot", totExpense);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("budget.jsp");
        dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}
