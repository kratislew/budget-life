package com.budget.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import com.budget.beans.User;
import com.budget.services.UserService;

public class UserDao implements UserService {

    public Map<UUID, User> readUsers() {
        User user = null;
        Map<UUID, User> users = new LinkedHashMap<UUID, User>();

        try {
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get all users
            String sql = "select * from users;";
            PreparedStatement statement = connection.prepareStatement(sql);

            // execute query, get result set and return User info
            ResultSet set = statement.executeQuery();
            while (set.next()) {
                user = new User();
                user.setId(UUID.fromString(set.getString("uuid")));
                user.setUserName(set.getString("username"));
                user.setPassword(set.getString("password"));
                user.setEmail(set.getString("email"));
                user.setFirstName(set.getString("firstName"));
                user.setLastName(set.getString("lastName"));
                user.setAuthenticated(set.getBoolean("isAuthenticated"));
                user.setIncomeAmount(set.getDouble("incomeAmount"));
                user.setIncomeType(set.getString("incomeType"));
                user.updateLoginStatus(set.getBoolean("isLogIn"));
                users.put(user.getId(), user);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return users;
    }

    public User readUser(String id) {
        User user = null;
        try {
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get the user
            String sql = "select * from users where uuid=?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, id);

            // execute query, get resultset and return user info
            ResultSet set = statement.executeQuery();
            while (set.next()) {
            	user = new User();
                user.setId(UUID.fromString(set.getString("uuid")));
                user.setUserName(set.getString("username"));
                user.setPassword(set.getString("password"));
                user.setEmail(set.getString("email"));
                user.setFirstName(set.getString("firstName"));
                user.setLastName(set.getString("lastName"));
                user.setAuthenticated(set.getBoolean("isAuthenticated"));
                user.setIncomeAmount(set.getDouble("incomeAmount"));
                user.setIncomeType(set.getString("incomeType"));
                user.updateLoginStatus(set.getBoolean("isLogIn"));
            }

        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return user;
    }

    public User findUser(String user, String pass) {
    	User temp = null;
    	try {
        	
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get the User
            String sql = "select * from users where username=?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, user);
            
            ResultSet set = statement.executeQuery();
            while(set.next())
            {
            	temp = new User();
                temp.setId(UUID.fromString(set.getString("uuid")));
                temp.setUserName(set.getString("username"));
                temp.setPassword(set.getString("password"));
                temp.setEmail(set.getString("email"));
                temp.setFirstName(set.getString("firstName"));
                temp.setLastName(set.getString("lastName"));
                temp.setAuthenticated(set.getBoolean("isAuthenticated"));
                temp.setIncomeAmount(set.getDouble("incomeAmount"));
                temp.setIncomeType(set.getString("incomeType"));
                temp.updateLoginStatus(set.getBoolean("isLogIn"));
            }
            
            return temp;

        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return temp;
    }
    
    
    public void createUser(User user) {
        try {
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get the user
            String sql = "insert into users (uuid, username, password, email, firstName, lastName, isAuthenticated, incomeAmount, incomeType, isLogIn)"
            		+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, user.getId().toString());
            statement.setString(2, user.getUserName());
            statement.setString(3, user.getPassword());
            statement.setString(4, user.getEmail());
            statement.setString(5, user.getFirstName());
            statement.setString(6, user.getLastName());
            statement.setBoolean(7, user.isAuthenticated());
            statement.setDouble(8, user.getIncomeAmount());
            statement.setString(9, user.getIncomeType());
            statement.setBoolean(10, user.isLogIn());

            // execute query, update resultset
            statement.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void updateUser(User user) {
        try {
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get the user
            String sql = "update users set username=?, password=?, email=?, firstName=?, lastName=?, isAuthenticated=?, "
            		+ "incomeAmount=?, incomeType=?, isLogIn=? where uuid=?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, user.getUserName());
            statement.setString(2, user.getPassword());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getFirstName());
            statement.setString(5, user.getLastName());
            statement.setBoolean(6, user.isAuthenticated());
            statement.setDouble(7, user.getIncomeAmount());
            statement.setString(8, user.getIncomeType());
            statement.setString(9, user.getId().toString());
            statement.setBoolean(10, user.isLogIn());

            // execute query, update resultset
            statement.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void deleteUser(String id) {
        try {
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get the User
            String sql = "delete from users where uuid=?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, UUID.fromString(id).toString());

            // execute query, delete resultset
            statement.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    
    public boolean verifyUser(String user, String pass) {
        try {
        	
        	String realPass = "";
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get the User
            String sql = "select password from users where username=?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, user);
            
            ResultSet set = statement.executeQuery();
            while(set.next())
            {
            	realPass = set.getString("password");
            }
            
            if(realPass.equals(pass)) {
            	return true;
            }
            else {
            	return false;
            }

        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    @Override
    public void createOrUpdateUser(User user) {
        User localUser = readUser(user.getId().toString());
        if (localUser == null) {
            createUser(user);
        } else {
            updateUser(user);
        }
    }

    public User findUser(String email) {
    	User temp = null;
    	try {
        	
            // get connection to database
            Connection connection = DBConnection.getConnectionToDatabase();

            // write select query to get the User
            String sql = "select * from users where email=?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, email);
            
            ResultSet set = statement.executeQuery();
            while(set.next())
            {
            	temp = new User();
                temp.setId(UUID.fromString(set.getString("uuid")));
                temp.setUserName(set.getString("username"));
                temp.setPassword(set.getString("password"));
                temp.setEmail(set.getString("email"));
                temp.setFirstName(set.getString("firstName"));
                temp.setLastName(set.getString("lastName"));
                temp.setAuthenticated(set.getBoolean("isAuthenticated"));
                temp.setIncomeAmount(set.getDouble("incomeAmount"));
                temp.setIncomeType(set.getString("incomeType"));
                temp.updateLoginStatus(set.getBoolean("isLogIn"));
            }
            
            return temp;

        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return temp;
    }
    
}
