package com.budget.inmemory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import com.budget.beans.User;
import com.budget.services.UserService;

public class UserInMemory implements UserService {

    private Map<UUID, User> users;

    public UserInMemory() {
        this.users = new LinkedHashMap<UUID, User>();
    }

    @Override
    public Map<UUID, User> readUsers() {
        return users;
    }

    @Override
    public User readUser(String id) {
        return users.get(UUID.fromString(id));
    }

    @Override
    public void createUser(User user) {
        updateUser(user);
    }

    @Override
    public void updateUser(User user) {
        users.put(user.getId(), user);
    }

    @Override
    public void deleteUser(String id) {
        users.remove(UUID.fromString(id));
    }

    @Override
    public void createOrUpdateUser(User user) {
        User localUser = readUser(user.getId().toString());
        if (localUser == null) {
            createUser(user);
        } else {
            updateUser(user);
        }
    }

	@Override
	public boolean verifyUser(String user, String pass) {
		return verifyUser(user, pass);
	}

	@Override
	public User findUser(String user, String pass) {
		User temp = findUser(user, pass);
		return temp;
	}
	
	@Override
	public User findUser(String email) {
		User temp = findUser(email);
		return temp;
	}

}
