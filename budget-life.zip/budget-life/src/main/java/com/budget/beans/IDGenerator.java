package com.budget.beans;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class IDGenerator {

    private static IDGenerator generator;
    private static boolean initialized = false;
    private static List<UUID> userIDs = new ArrayList<UUID>();
    private IDGenerator() {}

    private void init() {
    }

    public static synchronized IDGenerator getInstance() {

        if (initialized) {
            return generator;
        }
        generator = new IDGenerator();
        generator.init();
        initialized = true;
        return generator;

    }

    public UUID userID() {

        UUID id;
        do {
            id = UUID.randomUUID();
        } while(userIDs.contains(id));
        userIDs.add(id);
        
        return id;
    }


}
