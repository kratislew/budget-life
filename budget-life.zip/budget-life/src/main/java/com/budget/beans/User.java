package com.budget.beans;

import java.util.UUID;

public class User {
	
	private UUID userID;
	private String userName;
	private String password;
	private String email;
	private String avatar;
	private String firstName;
	private String lastName;
	private boolean isAuthenticated;
	private double incomeAmount;
	private String incomeType;
	private boolean isLoggedIn;
	
	public User() {}
	
	public User(String uName, String pass, String email, String fName, String lName, double income, String incomeT) {
		this.userID = IDGenerator.getInstance().userID();
		userName = uName;
		password = pass;
		this.email = email;
		firstName = fName;
		lastName = lName;
		incomeAmount = income;
		incomeType = incomeT;
		isAuthenticated = false;
		isLoggedIn = false;
	}

	public UUID getId() {
		return userID;
	}

	public void setId(UUID userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public boolean isAuthenticated() {
		return isAuthenticated;
	}

	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	public double getIncomeAmount() {
		return incomeAmount;
	}

	public void setIncomeAmount(double incomeAmount) {
		this.incomeAmount = incomeAmount;
	}

	public String getIncomeType() {
		return incomeType;
	}

	public void setIncomeType(String incomeType) {
		this.incomeType = incomeType;
	}
	
	public void updateLoginStatus(Boolean b) {
		isLoggedIn = b;
	}
	
	public boolean isLogIn() {
		return isLoggedIn;
	}

	
}