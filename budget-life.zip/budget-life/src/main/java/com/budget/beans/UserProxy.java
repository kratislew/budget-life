package com.budget.beans;

import java.util.UUID;

public class UserProxy {
	private User _user = new User();

	public UUID getId() {
		return _user.getId();
	}

	public void setId(UUID userID) {
		_user.setId(userID);
	}

	public String getUserName() {
		return _user.getUserName();
	}

	public void setUserName(String userName) {
		_user.setUserName(userName);
	}
	
	public String getPassword() {
		return _user.getPassword();
	}

	public void setPassword(String password) {
		_user.setPassword(password);;
	}
	
	public String getEmail() {
		return _user.getEmail();
	}
	
	public void setEmail(String email) {
		_user.setEmail(email);
	}
	
	public String getAvatar() {
		return _user.getAvatar();
	}

	public void setAvatar(String avatar) {
		_user.setAvatar(avatar);
	}

	public String getFirstName() {
		return _user.getFirstName();
	}

	public void setFirstName(String firstName) {
		_user.setFirstName(firstName);
	}

	public String getLastName() {
		return _user.getLastName();
	}

	public void setLastName(String lastName) {
		_user.setLastName(lastName);
	}
	
	public boolean isAuthenticated() {
		return _user.isAuthenticated();
	}

	public void setAuthenticated(boolean isAuthenticated) {
		_user.setAuthenticated(isAuthenticated);
	}

	public double getIncomeAmount() {
		return _user.getIncomeAmount();
	}

	public void setIncomeAmount(double incomeAmount) {
		_user.setIncomeAmount(incomeAmount);
	}

	public String getIncomeType() {
		return _user.getIncomeType();
	}

	public void setIncomeType(String incomeType) {
		_user.setIncomeType(incomeType);
	}
	
	public void updateLoginStatus(Boolean b) {
		_user.updateLoginStatus(b);
	}
	
	public boolean isLogIn() {
		return _user.isLogIn();
	}

	
}