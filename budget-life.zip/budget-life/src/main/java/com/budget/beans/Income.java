package com.budget.beans;

public class Income extends Value{
	public Income() {
		super();
	}
	
	public Income(double amount, String title, String desc) {
		super(amount, title, desc);
	}
}